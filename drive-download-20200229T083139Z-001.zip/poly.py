class first:
    def __init__(self,x,):
        self.a=x
    def__add__(self,y):
        return self.a+y.a 

obj1=first(1)
obj2=first(2)
obj3=first("HELLO")
obj4=first("WORLD")

